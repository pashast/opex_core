<?php
// Heading
$_['heading_title']    = 'Opencart.express core files';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified module!';
$_['text_edit']        = 'Edit Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_ac_limit']   = 'Autocomplete limit';
$_['entry_ac_full_limit']   = 'Autocomplete in popup limit';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify this module!';